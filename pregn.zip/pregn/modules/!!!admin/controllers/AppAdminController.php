<?php

namespace app\modules\admin\controllers;
use yii\web\Controller;



class AppAdminController extends Controller{


} 