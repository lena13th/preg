<div class="admin-default-index container">
    <h1>Добро пожаловать!</h1>
    <p>
        Это панель администратора.
    </p>
</div>
