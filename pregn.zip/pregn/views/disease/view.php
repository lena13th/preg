<?php
use yii\helpers\Html;
use yii\helpers\Url;


$this->params['active_page'][] = 'disease';

?>
<h1><?= $disease->name ?> </h1>

        <?= $disease->content ?>
