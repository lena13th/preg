<?php

$this->params['active_page'][] = 'hemostas';

?>
<h1><?= $hemostas->title ?></h1>
<?= $hemostas->content ?>