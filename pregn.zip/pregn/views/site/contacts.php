<?php

$this->params['active_page'][] = 'contacts';

?>
<h1>Контакты</h1>

Описание: <?= $main->field_contacts ?>
<br><br>
Телефон: <?= $main->phone ?>
<br><br>
Email: <?= $main->email ?>