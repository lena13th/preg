<?php

?>
<footer class="footer_container content_row col-xs-12">
    <div class="footer_title">Беременность+</div>
    <a href="https://vk.com" class="footer_vk_link" target="_blank"><i class="fa fa-vk"></i></a>
    <div class="footer_year"><?= date('Y') ?> г.</div>
</footer>
