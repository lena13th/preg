<?php
use yii\helpers\Url;

?>
<nav class="nav_line">
    <?php $this->beginContent('@app/views/layouts/menu.php'); ?>
    <?php $this->endContent(); ?>
</nav>