<?php 

namespace app\models;
use yii\db\ActiveRecord;

class Document extends ActiveRecord{




}