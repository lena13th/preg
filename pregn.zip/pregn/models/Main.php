<?php

namespace app\models;
use yii\db\ActiveRecord;

class Main extends ActiveRecord
{


}
