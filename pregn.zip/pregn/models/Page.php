<?php 

namespace app\models;
use yii\db\ActiveRecord;

class Page extends ActiveRecord{




}