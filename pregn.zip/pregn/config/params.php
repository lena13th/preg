<?php

return [
    'adminEmail' => 'admin@example.com',
    'company_id' =>'1',

];
